//
//  ViewController.swift
//  MultiLangDemo
//
//  Created by test on 7/6/15.
//  Copyright (c) 2015 test. All rights reserved.
//

import UIKit

class ViewController: UIViewController
{

    @IBOutlet weak var welcomeLabel: UILabel!
    @IBOutlet weak var welcomeTextLabel: UILabel!
    
    @IBOutlet weak var chooseLanguageTableView: UITableView!
    
    var languages=[String]()
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        AppHelper.saveToUserDefault("English", key: "LanguageKey")
        languages = ["English","French"]
        self.setValues()
        
        
    }

    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


    @IBAction func buttonAction(sender: AnyObject)
    {
        var changeLanguage:UIButton=sender as UIButton
        if changeLanguage.selected
        {
        }
        changeLanguage.selected = !changeLanguage.selected
    }
    
    func methodToChangeTextAccordingToLanguage(var isEnglish:Bool)
    {
        if isEnglish
        {
            //label1.te
        }
    }
}

extension ViewController:UITableViewDelegate,UITableViewDataSource
{

    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath)
    {
        println(languages)
        println(indexPath.row)
        AppHelper.saveToUserDefault(languages[indexPath.row], key: "LanguageKey")
        println(AppHelper.userDefaultForAny("LanguageKey"))
        self.setValues()
    }
    
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell
    {
        
        var cell : UITableViewCell! = tableView.dequeueReusableCellWithIdentifier("ChooseLanguageCell", forIndexPath: indexPath) as? UITableViewCell
        
        var languageLabel:UILabel = cell.viewWithTag(10) as UILabel!
        languageLabel.text = languages[indexPath.row]
        return cell
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return languages.count
    }
    
    
    func tableView(tableView: UITableView, viewForHeaderInSection section: Int) -> UIView?
    {
        var viewHeader:UIView = UIView(frame: CGRectMake(0, 0, tableView.frame.size.width, 25))
        viewHeader.backgroundColor = UIColor.lightGrayColor()
        var labelHeader:UILabel = UILabel(frame: CGRectMake(10, 0, viewHeader.frame.size.width, 25))
        labelHeader.textColor = UIColor.blackColor()
        labelHeader.font = UIFont(name: "Arial", size: 15.0)
        labelHeader.text = "Choose language"
        viewHeader.addSubview(labelHeader)
        return viewHeader
    }
    
    
    func tableView(tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat
    {
        return 25
    }
    
    
    func setValues()
    {
        welcomeLabel.text = AppHelper.localisedStringFromTable("Welcome")
        welcomeTextLabel.text = AppHelper.localisedStringFromTable("WelcomeData")
    }
}



