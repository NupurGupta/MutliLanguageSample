   //
//  AppHelper.swift
//  Yumcheck
//
//  Created by test on 9/22/14.
//  Copyright (c) 2014 Appstudioz. All rights reserved.
//

import Foundation
import UIKit

class AppHelper:NSObject
{
    var activityView:UIView?
    var activityIndicator : UIActivityIndicatorView?

    class var sharedInstance : AppHelper
    {
        struct Static
        {
            static var onceToken : dispatch_once_t = 0
            static var instance : AppHelper? = nil
        }
        dispatch_once(&Static.onceToken)
        {
                Static.instance = AppHelper()
        }
        return Static.instance!
    }
    
    
    //MARK: UserDefault
    class func saveToUserDefault(value:AnyObject, key:String)
    {
        NSUserDefaults.standardUserDefaults().setObject(value, forKey:key)
        NSUserDefaults.standardUserDefaults().synchronize()
    }
    
    class func userDefaultForKey(key:String) -> String
    {
        var optional:String?
        optional = NSUserDefaults.standardUserDefaults().objectForKey(key) as? String
        
        
        if (optional != nil)
        {
            return NSUserDefaults.standardUserDefaults().objectForKey(key) as NSString
        }
        else
        {
            return ""
        }
    }
    
    class func userDefaultForAny(key:String) -> AnyObject?
    {
        var optional:AnyObject?
        optional = NSUserDefaults.standardUserDefaults().objectForKey(key) as AnyObject!
        
        
        if (optional != nil)
        {
            return NSUserDefaults.standardUserDefaults().objectForKey(key) as AnyObject!
        }
        else
        {
            return nil
        }
        
    }
    
    class func userdefaultForArray(key:String) -> Array<AnyObject>
    {
        return NSUserDefaults.standardUserDefaults().objectForKey(key) as Array
    }
    
    class func removeFromUserDefaultForKey(key:String)
    {
        NSUserDefaults.standardUserDefaults().removeObjectForKey(key)
        NSUserDefaults.standardUserDefaults().synchronize()
        
    }
    
    class func localisedStringFromTable(var Key:String) -> String
    {
        println(NSLocalizedString(Key, tableName: self.userDefaultForAny("LanguageKey") as? String, bundle: NSBundle.mainBundle(), value: "", comment: ""))
        
        
        return NSLocalizedString(Key, tableName: self.userDefaultForAny("LanguageKey") as? String, bundle: NSBundle.mainBundle(), value: "", comment: "")
    }
    
    
    
    //MARK: AlertView
    class func showALertWithTag(tag:Int, title:String, message:String?,delegate:AnyObject!, cancelButtonTitle:String?, otherButtonTitle:String?)
    {
        let alert = UIAlertView()
        
        alert.tag = tag
        alert.title = title
        alert.message = message
        
        println("delegate       \(delegate)")
        alert.delegate = delegate
        if (cancelButtonTitle != nil)
        {
            alert.addButtonWithTitle(cancelButtonTitle!)
        }
        if (otherButtonTitle != nil)
        {
            alert.addButtonWithTitle(otherButtonTitle!)
        }
        
        alert.show()
        
    }
    
       
        
}